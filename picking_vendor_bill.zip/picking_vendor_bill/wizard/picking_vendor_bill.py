from odoo import models, fields, api

class RegisterPayment(models.TransientModel):
    _name = 'picking.vendor.bill'

    bill_date = fields.Date(string="Bill date")
    journal_id = fields.Many2one('account.journal', string='Journal')

    def action_create_vendor_bill(self):
        picking = self.env['stock.picking'].browse(self._context.get('active_id'))
        purchase_order = picking.purchase_id

        invoice_lines = []

        for move_line in picking.move_ids:
            if move_line.is_done >= 1:
                line_vals = {
                    'product_id': move_line.product_id.id,
                    'quantity': move_line.product_uom_qty,
                    'purchase_line_id': move_line.purchase_line_id.id,
                }
                invoice_lines.append((0, 0, line_vals))

        if invoice_lines:
            bill_vals = {
                'move_type': 'in_invoice',
                'partner_id': purchase_order.partner_id.id,
                'invoice_date': self.bill_date,
                'invoice_origin': f"{purchase_order.name}, {picking.name}",
                'ref': picking.name,
                'journal_id': self.journal_id.id,
                'invoice_line_ids': invoice_lines,
            }

            created_bill = self.env['account.move'].create(bill_vals)
            created_bill.action_post()

            picking.write({'vendor_bill_ids': [(4, created_bill.id)]})

            return [created_bill.id]

        return []
