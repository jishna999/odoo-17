from odoo import models, fields,api



class StockPicking(models.Model):
    _inherit = 'stock.picking'

    vendor_bill_ids = fields.Many2many('account.move', string="Vendor Bills", readonly=True,
                                       domain=[('move_type', '=', 'in_invoice')])

    invoice_count = fields.Integer(compute="_compute_invoice", string='Bill Count', copy=False, default=0, store=True)

    @api.depends('vendor_bill_ids')
    def _compute_invoice(self):
        for order in self:
            invoices = order.mapped('vendor_bill_ids')
            order.vendor_bill_ids = invoices
            order.invoice_count = len(invoices)

    def action_view_vendor_bill(self):
        action = self.env.ref('account.action_move_in_invoice_type')
        result = action.read()[0]
        result['domain'] = [('id', 'in', self.vendor_bill_ids.ids)]
        return result
